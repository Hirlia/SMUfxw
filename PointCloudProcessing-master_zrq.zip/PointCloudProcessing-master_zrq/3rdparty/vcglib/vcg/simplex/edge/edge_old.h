#ifndef __VCGLIB_EDGE_TYPE
#define __VCGLIB_EDGE_TYPE

#define EDGE_TYPE Edge

#include <vcg/simplex/edge/base.h>

#undef EDGE_TYPE

#endif
