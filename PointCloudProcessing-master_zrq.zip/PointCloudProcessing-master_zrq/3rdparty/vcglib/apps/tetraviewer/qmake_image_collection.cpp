/****************************************************************************
** Image collection for project 'TetraView'.
**
** Generated from reading image files:
**      images/editcopy
**      images/editcut
**      images/editpaste
**      images/filenew
**      images/fileopen
**      images/filesave
**      images/print
**      images/redo
**      images/searchfind
**      images/undo
**      images/Open64.png
**
** Created: Mon Oct 4 19:00:57 2004
**      by: The User Interface Compiler ($Id: qmake_image_collection.cpp,v 1.3 2004-10-04 18:01:36 ganovelli Exp $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include <qdict.h>
#include <qdragobject.h>
#include <qimage.h>
#include <qmime.h>
